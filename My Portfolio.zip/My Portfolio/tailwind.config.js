/** @type {import('tailwindcss').Config} */
module.exports = {
  darkmode:'class',
  content: ['./dark.html'],
  theme: {
    extend: {},
  },
  plugins: [],
}

