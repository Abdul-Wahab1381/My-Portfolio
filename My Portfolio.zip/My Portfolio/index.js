function home() {
    window.location.href = 'index.html';
}

function service() {

    window.location.href = 'services.html';

}
function contact() {

    window.location.href = 'contactus.html';

}
function portfolio(){
    window.location.href='portfolio.html';
}
document.getElementById('button').addEventListener('click', function () {
    let menu = document.getElementById('menu');

    if (menu.classList.contains('opacity-0')) {
            menu.classList.remove('opacity-0', 'scale-95');
            menu.classList.add('opacity-100', 'scale-100');
            menu.classList.add('flex','flex-col','gap-3');
            menu.classList.add('z-10','bg-[#6B89C5]','w-full','h-[370px]','rounded-[20px]');
    } else {
            menu.classList.remove('opacity-100', 'scale-100');
            menu.classList.add('opacity-0', 'scale-95');
    }
});
